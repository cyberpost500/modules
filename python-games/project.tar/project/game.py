#!/usr/bin/python
# -*- coding: utf-8 -*-
''' This will eventually be a game.

Initially it serves as an example of how to create an SDL window.

The window displays "Hello, World!" and has a title of "The Game".  A small
yellow and purple circle is also drawn in the upper left corner and slides
towards the lower right as the program runs.

The frame rate of the window is limited to 10 fps so that the system doesn't
attempt to update the window as fast as it can.

The window will not respond to any key presses, but it can be closed through
the usual means from the operating system (close button or equivalent).
'''

import pygame

class Shape(object):
    '''
    Defines a simple shape that can be drawn to the screen.
    '''
    LEFT = 0
    TOP = 1
    RIGHT = 2
    BOTTOM = 3

    def __init__(self, color, x, y, size, border): #pylint: disable=too-many-arguments
        '''
        Creates a Shape with a center at x,y and a radius of the specified size.
        '''
        self.color = color
        self.x = x #pylint: disable=invalid-name
        self.y = y #pylint: disable=invalid-name
        self.size = size
        self.border = border

    def draw(self, surface):
        '''
        Draws the shape on the provided surface.
        '''
        center = [self.x, self.y]
        pygame.draw.circle(surface, self.color, center, self.size, self.border)

    def overlaps(self, other):
        '''
        Tests to see if the provided shape overlaps this shape.
        This is loosely based on the distance formula.
                 _________________
            d = √(x₂-x₂)²+(y₂-y₁)²

        If the distance between the two shapes is less than sum of the sizes,
        then the shapes overlap.

        Since this test might be done frequently, we will reduce the complexity
        of the math by instead comparing the squares of the two sizes instead
        of taking the square root.
        '''
        return (self.x - other.x)**2 + (self.y - other.y)**2 < (self.size+other.size)**2 #pylint: disable=line-too-long

class MovingShape(Shape):
    '''
    Creates a shape that is able to slide around the screen.
    '''
    def __init__(self, color, x, y, size, border, speed, bounds): #pylint: disable=too-many-arguments
        super(MovingShape, self).__init__(color, x, y, size, border)
        self.speed_x = speed
        self.speed_y = speed
        self.bounds = bounds

    def move(self):
        '''
        Moves the shape according to its speed.
        '''
        self.x += self.speed_x
        self.y += self.speed_y
        self.enforce_bounds()

    def enforce_bounds(self):
        '''
        Prevents the shape from moving off a screen edge.
        '''
        if self.x < self.bounds[Shape.LEFT]:
            self.x = self.bounds[Shape.LEFT]

        if self.y < self.bounds[Shape.TOP]:
            self.y = self.bounds[Shape.TOP]

        if self.x > self.bounds[Shape.RIGHT]:
            self.x = self.bounds[Shape.RIGHT]

        if self.y > self.bounds[Shape.BOTTOM]:
            self.y = self.bounds[Shape.BOTTOM]

class BouncingShape(MovingShape):
    '''
    Creates a shape that not only moves, but if it hits an edge it will bounce.
    '''

    def __init__(self, color, x, y, size, border, speed, bounds): #pylint: disable=too-many-arguments
        super(BouncingShape, self).__init__(color, x, y, size, border, speed, bounds) #pylint: disable=line-too-long

    def move(self):
        '''
        Moves the shape according to its speed, but also "bounces" if it hits
        an edge.
        '''
        old_x = self.x
        old_y = self.y

        super(BouncingShape, self).move()

        if old_x == self.x and (self.x == self.bounds[Shape.LEFT] or self.x == self.bounds[Shape.RIGHT]): #pylint: disable=line-too-long
            self.speed_x *= -1
        if old_y == self.y and (self.y == self.bounds[Shape.TOP] or self.y == self.bounds[Shape.BOTTOM]): #pylint: disable=line-too-long
            self.speed_y *= -1

class BouncingRectangle(BouncingShape):
    '''
    Creates a bouncing rectangle much like the BouncingShape, but uses a
    rectangle instead of a circle.
    '''
    def draw(self, surface):
        half = self.size/2
        top = self.x-half
        left = self.y-half
        rectangle = pygame.rect.Rect(top, left, self.size, self.size)
        pygame.draw.rect(surface, self.color, rectangle, self.border)


def create_window(width=800, height=600, title="The Game", fullscreen=False):
    '''
    Configures the main window of the game to the specified dimensions (or
    fullscreen) and sets the title.
    '''
    if fullscreen:
        width = 0
        height = 0

    screen = pygame.display.set_mode((width, height))
    pygame.display.set_caption(title)
    return screen

def get_window_bounds(screen):
    '''
    Fetches the size of the provided window and returns it as a list.
    The format of the list is [left, top, right, bottom].
    '''
    size = screen.get_size()
    return [0, 0, size[0], size[1]]

def create_background(dimensions):
    '''
    Creates the main background of the game screen.
    '''
    background = pygame.Surface(dimensions) #pylint: disable=too-many-function-args
    background.fill((85, 0, 0), [0, 0, dimensions[0], dimensions[1]])
    return background

def main():
    '''
    This contains the main logic of the program, it's in a separate function so
    that the other functions in this program may be reused as a module.
    '''
    pygame.init() #pylint: disable=no-member
    screen = create_window()
    bounds = get_window_bounds(screen)
    running = True
    clock = pygame.time.Clock()
    font = pygame.font.Font(None, 100) #use default font, size 100
    text = font.render("Hello, World!", 1, (0, 0, 0), (0xff, 0, 0))
    shapes = []
    shapes.append(BouncingShape((0xff, 0xff, 0), 0, 0, 10, 1, 10, bounds))
    shapes.append(BouncingShape((0xff, 0, 0xff), 10, 0, 10, 1, 7, bounds))
    shapes.append(BouncingRectangle((0, 0xff, 0xff), 10, 0, 10, 1, 7, bounds))
    background = create_background(screen.get_size())

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: #pylint: disable=no-member
                running = False

        ##
        # blit the background and destroy anything that was on the screen
        screen.blit(background, bounds)

        ##
        # blit the hello world text, because why not...
        screen.blit(text, bounds)

        ##
        # In addition to the text, multiple circles on the screen.
        for shape in shapes:
            shape.move()
            shape.draw(screen)

        ##
        # The blit happens on the back buffer, so flip it so it gets displayed.
        pygame.display.flip()

        ##
        # At this point the program is going to loop back to the top, but it's
        # going to do this as fast as it can, which can be taxing on the
        # system, so we continue to limit the framerate.
        clock.tick(10)

    pygame.quit() #pylint: disable=no-member

if __name__ == "__main__":
    main()
