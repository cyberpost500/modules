#!/usr/bin/python
# -*- coding: utf-8 -*-
''' This will eventually be a game.

Initially it serves as an example of how to create an SDL window, create a
menu, add shapes, and handle basic user input.

The window has a title of "The Game".  Some moving shapes are drawn in that
window and a menu is accessible via the escape key.

The frame rate of the window is limited to 10 fps so that the system doesn't
attempt to update the window as fast as it can.

The window can be closed through the menu or the usual means from the operating
system (close button or equivalent).
'''

import pygame
import random

class Shape(object):
    '''
    Defines a simple shape that can be drawn to the screen.
    '''
    LEFT = 0
    TOP = 1
    RIGHT = 2
    BOTTOM = 3

    def __init__(self, color, x, y, size, border): #pylint: disable=too-many-arguments
        '''
        Creates a Shape with a center at x,y and a radius of the specified size.
        '''
        self.color = color
        self.x = x #pylint: disable=invalid-name
        self.y = y #pylint: disable=invalid-name
        self.size = size
        self.border = border

    def draw(self, surface):
        '''
        Draws the shape on the provided surface.
        '''
        center = [self.x, self.y]
        pygame.draw.circle(surface, self.color, center, self.size, self.border)

    def overlaps(self, other):
        '''
        Tests to see if the provided shape overlaps this shape.
        This is loosely based on the distance formula.
                 _________________
            d = √(x₂-x₂)²+(y₂-y₁)²

        If the distance between the two shapes is less than sum of the sizes,
        then the shapes overlap.

        Since this test might be done frequently, we will reduce the complexity
        of the math by instead comparing the squares of the two sizes instead
        of taking the square root.
        '''
        return (self.x - other.x)**2 + (self.y - other.y)**2 < (self.size+other.size)**2 #pylint: disable=line-too-long

    def __repr__(self):
        '''
        Produces a human-readable string for this Shape.
        '''
        return '%s [x: %d y: %d size: %d color: %s]' % (
            self.__class__.__name__, self.x, self.y, self.size, self.color)

class ImmobileShape(Shape):
    '''
    A movable shape that cannot be moved.
    '''
    def move(self):
        '''
        An empty move method so it can pretend to be movable.
        '''

class MovingShape(Shape):
    '''
    Creates a shape that is able to slide around the screen.
    '''
    def __init__(self, color, x, y, size, border, speed, bounds): #pylint: disable=too-many-arguments
        super(MovingShape, self).__init__(color, x, y, size, border)
        self.speed_x = speed
        self.speed_y = speed
        self.bounds = bounds

    def move(self):
        '''
        Moves the shape according to its speed.
        '''
        self.x += self.speed_x
        self.y += self.speed_y
        self.enforce_bounds()

    def enforce_bounds(self):
        '''
        Prevents the shape from moving off a screen edge.
        '''
        if self.x < self.bounds[Shape.LEFT]:
            self.x = self.bounds[Shape.LEFT]

        if self.y < self.bounds[Shape.TOP]:
            self.y = self.bounds[Shape.TOP]

        if self.x > self.bounds[Shape.RIGHT]:
            self.x = self.bounds[Shape.RIGHT]

        if self.y > self.bounds[Shape.BOTTOM]:
            self.y = self.bounds[Shape.BOTTOM]

class BouncingShape(MovingShape):
    '''
    Creates a shape that not only moves, but if it hits an edge it will bounce.
    '''

    def __init__(self, color, x, y, size, border, speed, bounds): #pylint: disable=too-many-arguments
        super(BouncingShape, self).__init__(color, x, y, size, border, speed, bounds) #pylint: disable=line-too-long

    def move(self):
        '''
        Moves the shape according to its speed, but also "bounces" if it hits
        an edge.
        '''
        old_x = self.x
        old_y = self.y

        super(BouncingShape, self).move()

        if old_x == self.x and (self.x == self.bounds[Shape.LEFT] or self.x == self.bounds[Shape.RIGHT]): #pylint: disable=line-too-long
            self.speed_x *= -1
        if old_y == self.y and (self.y == self.bounds[Shape.TOP] or self.y == self.bounds[Shape.BOTTOM]): #pylint: disable=line-too-long
            self.speed_y *= -1

class BouncingRectangle(BouncingShape):
    '''
    Creates a bouncing rectangle much like the BouncingShape, but uses a
    rectangle instead of a circle.
    '''
    def draw(self, surface):
        half = self.size/2
        top = self.x-half
        left = self.y-half
        rectangle = pygame.rect.Rect(top, left, self.size, self.size) #pylint: disable=no-member
        pygame.draw.rect(surface, self.color, rectangle, self.border)

class BouncingPolygon(BouncingShape):
    '''
    This is a bouncing shape defined by a polygon that bounces after it
    reaches its bounds by inverting its speeds.
    '''

    def __init__(self, polygon, color, x, y, size, border, speed_x, speed_y, bounds): #pylint: disable=too-many-arguments, line-too-long
        '''
        Creates the polygon to move based upon its dx and dy values, but
        inverts its dx or dy when the respective x or y value hits the
        edge of the bounds.
        '''
        super(BouncingPolygon, self).__init__(
            color, x, y, size, border, speed_x, bounds)
        self.speed_y = speed_y
        ## The unmodified polygon, centered around the origin
        self.original = polygon[:]
        self.polygon = polygon[:]
        self.move()
        self._size = size

    def draw(self, screen):
        self.size = self._size
        pygame.draw.polygon(screen, self.color, self.polygon, self.border)

    def move(self):
        self.polygon = []
        for p in self.original:
            self.polygon.append([p[0]+self.x, p[1]+self.y])
        super(BouncingPolygon, self).move()

    def point_overlaps(self, x, y):
        '''
        Tests to see if the specified x,y point overlaps any point within the
        polygon described by this instance.  This function was adapted from
        http://www.ariel.com.au/a/python-point-int-poly.html

        @return True if the specified point overlaps any points within the
                polygon.
        '''
        poly = self.polygon
        n = len(poly)
        inside = False

        p1x, p1y = poly[0]
        for i in range(n+1):
            p2x, p2y = poly[i % n]
            if y > min(p1y, p2y):
                if y <= max(p1y, p2y):
                    if x <= max(p1x, p2x):
                        if p1y != p2y:
                            xinters = (y-p1y)*(p2x-p1x)/(p2y-p1y)+p1x
                        if p1x == p2x or x <= xinters:
                            inside = not inside
            p1x, p1y = p2x, p2y

        return inside

    def polygon_overlaps(self, other):
        '''
        Tests to see if any point within the provided polygon overlaps any
        point inside this polygon.
        This works by iterating over the vertices of each polygon and testing
        to see if the single point is within the other polygon.

        @param other A BouncingPolygon @returns
        True if the provided BouncingPolygon overlaps any points within this
        polygon
        '''
        #if any of the outside points of poly 1 are inside poly 2
        #or any of the outside points of poly 2 are inside poly 1
        #then it's more or less true
        for p in self.polygon:
            if other.point_overlaps(p[0], p[1]):
                return True

        for p in other.polygon:
            if self.point_overlaps(p[0], p[1]):
                return True

        return False

    def overlaps(self, other):
        '''Tests to see if the provided Shape or BouncingPolygon overlaps any
        point inside this BouncingPolygon.
        @param other A BouncingPolygon or Shape.
        @returns True if the specified polygon or shape is within this polygon
        '''
        if isinstance(other, BouncingPolygon):
            return self.polygon_overlaps(other)
        else:
            return super(BouncingPolygon, self).overlaps(other)

class BouncingTriangle(BouncingPolygon):
    '''
    This is a bouncing polygon in the shape of a triangle with an x and y
    coordinate pair that refers to the center of the polygon.
    '''
    def __init__(self, color, x, y, size, border, speed_x, speed_y, bounds): #pylint: disable=too-many-arguments, line-too-long, too-many-locals
        #the polygon will be offset by x and y when drawn
        #so create it around the origin (0,0) for now
        fudge = 3
        top_x = 0
        top_y = (0-size/2) *  fudge
        bottom_left_x = (0-size/2) * fudge
        bottom_left_y = (0+size/2) * fudge
        bottom_right_x = (0+size/2) * fudge
        bottom_right_y = (0+size/2) * fudge
        polygon = [
            [top_x, top_y],
            [bottom_left_x, bottom_left_y],
            [bottom_right_x, bottom_right_y]]
        super(BouncingTriangle, self).__init__(
            polygon, color, x, y, size, border, speed_x, speed_y, bounds)

class Menu(object):
    '''
    A rudimentary menu featuring a title and a set of menu items that may be
    selected.
    '''

    def __init__(self, items, padding=10):
        '''
        Create a menu, the first MenuItem in the list is the menu title, each
        successive MenuItem is a selectable choice.

        @param items A list (or tuple) of type MenuItem.
        @param padding integer value specifying extra padding between items.
        '''
        ## All items in the Menu
        self.items = items
        ##
        # The currently selected menu index.  It starts at one because the
        # title would be zero.
        self.selected = 1
        ## The extra padding between menu items
        self.padding = padding

    def get_selected(self):
        '''
        Gets the MenuItem that is currently active, as an actual menu item, to
        get the selected index, just use the `selected` variable directly.
        '''
        return self.items[self.selected]

    def blit(self, surface, bounds):
        '''
        Blits the menu to the specified surface.

        @param surface an SDL surface such as the screen.
        @param bounds a rect used to center menu items.
        '''
        start_x = 0
        start_y = 0

        count = 0
        for item in self.items:
            start_x = ((bounds[0] + bounds[2])/2) - (item.width/2)
            start_y = start_y + item.height + self.padding
            ##
            # If the selected item is the current one (count == self.selected),
            # then toggle the inverted option.
            item.blit(surface, [start_x, start_y, 400, item.size],
                      count == self.selected)
            start_y += item.size
            count += 1

    def select_up(self):
        '''
        Change the menu selection by moving up an item, wraps around when first
        item is passed.
        '''
        self.selected -= 1
        if self.selected <= 0: # 0 is title, skip to last...
            self.selected = len(self.items) - 1

    def select_down(self):
        '''
        Change the menu selection by moving down an item, wraps around when
        last item is passed.
        '''
        self.selected += 1
        if self.selected >= len(self.items):
            self.selected = 1 # 0 is title, skip to first...

    def process_input(self, event):
        '''
        When the menu is being displayed, this method allows switching through
        items and performing actions.
        '''
        state = MENU_STATE
        if event.key == pygame.K_ESCAPE: #pylint: disable=no-member
            state = PLAY_STATE
        elif event.key == pygame.K_RETURN: #pylint: disable=no-member
            self.get_selected().perform_action()
        elif event.key == pygame.K_DOWN: #pylint: disable=no-member
            self.select_down()
        elif event.key == pygame.K_UP: #pylint: disable=no-member
            self.select_up()
        return state

class MenuItem(object): #pylint: disable=too-many-instance-attributes
    '''
    This is a rudimentary MenuItem for the Menu class to use.  This is
    suitable for the menu title and selectable entries of the menu.
    Selected entries can be denoted by an inverted foreground and
    background, but this is handled by the Menu class.
    '''

    def __init__(self, text, size, foreground, background, action=None): #pylint: disable=too-many-arguments
        '''
        Creates a MenuItem with the specified text, using the specified font
        size, and using the specified foreground and background colors.

        @param text The text to be rendered as the label of the MenuItem.
        @param size The font size at which the text is rendered.
        @param foreground The foreground color used when rendering the font
               (SDL color, eg (r,g,b)).
        @param background The background color used when rendering the font
               (SDL color, eg (r,g,b))
        '''
        ## SDL Font to used to render text
        self.font = pygame.font.Font(None, size)
        ## Color used for the font foreground
        self.foreground = foreground
        ## Color used for the font background
        self.background = background
        ## The Font size used to render text
        self.size = size
        ## The text label of the MenuItem
        self.text = " %s " %text
        ## The width in pixels needed by the text once it is rendered
        self.width = 0
        ## The height in pixels needed by the text once it is rendered
        self.height = 0

        self.width, self.height = self.font.size(text)
        self.action = action or self._null_action
        self.action_args = {}

    def _null_action(self):
        '''
        Place holder/no op for a menu item that does nothing.
        '''

    def perform_action(self):
        '''
        Executes the action stored in the item.
        '''
        self.action(*self.action_args)

    def blit(self, surface, position, invert=False):
        '''
        Blits the MenuItem to the specified surface in the specified location,
        typically invoked by a parent Menu

        @param surface the SDL surface to blit against.
        @param position the rect governing placement of the MenuItem.
        @param invert boolean argument to swap the foreground and background
               color.
        '''
        if invert:
            render = self.font.render(self.text, 1, self.background,
                                      self.foreground)
        else:
            render = self.font.render(self.text, 1, self.foreground)

        surface.blit(render, position)


def create_window(width=800, height=600, title="The Game", fullscreen=False):
    '''
    Configures the main window of the game to the specified dimensions (or
    fullscreen) and sets the title.
    '''
    if fullscreen:
        width = 0
        height = 0

    screen = pygame.display.set_mode((width, height))
    pygame.display.set_caption(title)
    return screen

def get_window_bounds(screen):
    '''
    Fetches the size of the provided window and returns it as a list.
    The format of the list is [left, top, right, bottom].
    '''
    size = screen.get_size()
    return [0, 0, size[0], size[1]]

def create_background(dimensions):
    '''
    Creates the main background of the game screen.
    '''
    background = pygame.Surface(dimensions) #pylint: disable=too-many-function-args
    background.fill((85, 0, 0), [0, 0, dimensions[0], dimensions[1]])
    return background

def create_menu():
    '''
    Constructs a generic menu with a title of MENU (in white text), and the
    options play, reset, and quit.  Play calls `play`, reset calls `reset`, and
    quit calls `doquit`.
    '''

    return Menu([MenuItem("MENU", 40, WHITE, None),
                 MenuItem("play", 20, WHITE, BLACK, play),
                 MenuItem("reset", 20, WHITE, BLACK, reset),
                 MenuItem("quit", 20, WHITE, BLACK, doquit)])
def play():
    ''' Callback from the menu, action to take when play is selected.  '''
    global STATE #pylint: disable=global-statement
    STATE = PLAY_STATE

def reset():
    ''' Callback from the menu, action to take when reset is selected.  '''
    global STATE #pylint: disable=global-statement
    STATE = RESET_STATE

def doquit():
    ''' Callback from the menu, action to take when quit is selected.  '''
    global STATE #pylint: disable=global-statement
    STATE = QUIT_STATE

def colorize():
    '''
    Returns a random color.
    '''
    return (random.randint(0, 255),
            random.randint(0, 255),
            random.randint(0, 255))

def create_npc_shapes(bounds, count, size_limit):
    '''
    Creates a random number (5-10) shapes and returns them in a list of
    shapes.  They will have random sizes, fills, and speeds.
    '''
    shapes = []

    for i in range(0, count):
        choice = random.choice(range(1, 5))
        size = random.randint(5, size_limit)
        speed_x = random.randint(1, 5)
        speed_x *= random.choice([-1, 1])
        speed_y = random.randint(1, 5)
        speed_y *= random.choice([-1, 1])
        x = random.randint(0, bounds[Shape.RIGHT])
        y = random.randint(0, bounds[Shape.BOTTOM])
        color = colorize()
        border = random.randint(1, size)
        #if choice == 0:
        #    shapes.append(ImmobileShape(color, x, y, size, border))
        if choice == 1:
            shapes.append(
                MovingShape(color, x, y, size, border, speed_x,
                            bounds))
        elif choice == 2:
            shapes.append(
                BouncingShape(color, x, y, size, border,
                              speed_x, bounds))
            shapes[i].speed_y = speed_y
        elif choice == 3:
            shapes.append(
                BouncingRectangle(color, x, y, size, border,
                                  speed_x, bounds))
            shapes[i].speed_y = speed_y

        elif choice == 4:
            shapes.append(
                BouncingTriangle(color, x, y, size, border, speed_x, speed_y, bounds) #pylint: disable=too-many-arguments, line-too-long, too-many-locals
                )
    return shapes

def remove_and_resize(shapes):
    '''
    Iterates over all the shapes, removes any smaller shapes that collide with
    larger shapes and grows the larger shape by the size of the ingested
    smaller shape.
    '''
    remove_list = []
    for shape in shapes:
        for other in shapes:
            if shape is not other:
                if shape.overlaps(other):
                    if shape.size > other.size and other not in remove_list:
                        remove_list.append(other)
                        shape.size += other.size
                    elif shape.size < other.size and shape not in remove_list:
                        other.size += shape.size
                        remove_list.append(shape)

    for remove in remove_list:
        shapes.remove(remove)

    return shapes

def trim_missing(shapes, all_shapes):
    '''
    Removes shapes from the shapes list that don't appear in all_shapes.
    '''
    for shape in shapes:
        if shape not in all_shapes:
            shapes.remove(shape)

def create_food(bounds, limit=5):
    '''
    Creates a bunch of food items that are too small to grow and cannot move.

    @param limit The density of the food across the board.
    '''
    foods = []
    x_factor = bounds[Shape.RIGHT]/limit
    y_factor = bounds[Shape.BOTTOM]/limit
    for y in range(0, bounds[Shape.BOTTOM], y_factor):
        for x in range(0, bounds[Shape.RIGHT], x_factor):
            foods.append(
                ImmobileShape(colorize(), x, y, 4, 4))
    return foods

def initialize(bounds):
    '''
    Create the intial npc and food shapes.

    @return Tuple of (all, npcs, foods)
    '''
    npcs = create_npc_shapes(
        bounds, random.randint(5, 10), random.randint(5, 10))
    foods = create_food(bounds)
    all_shapes = foods[:]
    all_shapes.extend(npcs)
    return all_shapes, npcs, foods

def main():
    '''
    This contains the main logic of the program, it's in a separate function so
    that the other functions in this program may be reused as a module.
    '''
    global STATE #pylint: disable=global-statement
    pygame.init() #pylint: disable=no-member
    screen = create_window()
    bounds = get_window_bounds(screen)
    clock = pygame.time.Clock()
    background = create_background(screen.get_size())
    menu = create_menu()
    font = pygame.font.Font(None, 20)

    all_shapes, npcs, foods = initialize(bounds)
    while True:
        #todo: add player shape to all_shapes, too!
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN: #pylint: disable=no-member
                if STATE == MENU_STATE:
                    menu.process_input(event)

                if STATE == PLAY_STATE:
                    if event.key == pygame.K_ESCAPE: #pylint: disable=no-member
                        STATE = MENU_STATE

                if STATE == RESET_STATE:
                    all_shapes, npcs, foods = initialize(bounds)
                    STATE = PLAY_STATE
                    continue

        if STATE is QUIT_STATE:
            ##
            # Do whatever shutdown routine (graphical or otherwise) and then
            # exit.  For example, say goodbye, wait a period of time, and then
            # exit.
            break

        ##
        # No matter the state, the background is always redrawn.
        screen.blit(background, bounds)

        ##
        # Stamp the screen with the number of shapes remaining
        text = font.render('Remaining: %d' % len(npcs), 1, WHITE, BLACK)
        screen.blit(text,
                    [bounds[Shape.LEFT], bounds[Shape.BOTTOM]-20,
                     bounds[Shape.LEFT], bounds[Shape.BOTTOM]])

        if STATE == PLAY_STATE:
            ##
            # Draw all the shapes.
            for shape in all_shapes:
                shape.draw(screen)
                shape.move()

            remove_and_resize(all_shapes)
            trim_missing(foods, all_shapes)
            trim_missing(npcs, all_shapes)
            if len(npcs) <= 1:
                STATE = MENU_STATE

        elif STATE == MENU_STATE:
            menu.blit(screen, bounds)

        pygame.display.flip() ## Flip buffer to foreground to display updates.

        clock.tick(10) ## Limit framerate.

    pygame.quit() #pylint: disable=no-member


##
# There are some globals used for maintaining game state:
MENU_STATE = "MENU"
PLAY_STATE = "PLAY"
QUIT_STATE = "QUIT"
RESET_STATE = "RESET"
STATE = PLAY_STATE
##
# Some globals for colors:
BLACK = (0x00, 0x00, 0x00)
WHITE = (0xff, 0xff, 0xff)
GREEN = (0x00, 0xff, 0x00)
RED = (0xff, 0x00, 0x00)
YELLOW = (0xff, 0xff, 0x00)
BLUE = (0x00, 0x00, 0xff)

if __name__ == "__main__":
    main()
