package io.github.cyberpost500.helloworld;

/**
 * This is a very simple hello-world style application that just outputs a
 * greeting.
 */
public class HelloWorld {
    /**
     * Entry point of the application.
     * @param args Unused, but required.
     */
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
