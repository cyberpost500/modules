/**
 * This is a convenient place to put the hello world application, but that's
 * all it contains.
 */
package io.github.cyberpost500.helloworld;
